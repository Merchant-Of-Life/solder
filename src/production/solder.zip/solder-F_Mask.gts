G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*
G04 #@! TF.CreationDate,2026-09-18T16:08:48+04:00*
G04 #@! TF.ProjectId,solder,736f6c64-6572-42e6-9b69-6361645f7063,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-09-18 16:08:48*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.800000X1.800000*%
%ADD11C,1.800000*%
%ADD12C,1.500000*%
%ADD13C,1.440000*%
%ADD14C,1.600000*%
%ADD15R,1.100000X1.800000*%
%ADD16RoundRect,0.275000X0.275000X0.625000X-0.275000X0.625000X-0.275000X-0.625000X0.275000X-0.625000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D1*
X132770000Y-88500000D03*
D11*
X130230000Y-88500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,R1*
X145500000Y-97500000D03*
X148900000Y-97500000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,D2*
X163225000Y-88500000D03*
D11*
X165765000Y-88500000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,RV1*
X107940000Y-71540000D03*
X105400000Y-69000000D03*
X107940000Y-66460000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,R2*
X144190000Y-130000000D03*
X151810000Y-130000000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,Q1*
X192500000Y-63400000D03*
D16*
X191230000Y-61330000D03*
X189960000Y-63400000D03*
G04 #@! TD*
M02*
